import { useState } from 'react';
import AdminGateway from '@/components/AdminGateway';
import Header from '@/components/Header';
import TopBanner from '@/components/TopBanner';
import BatchesSection from '@/components/BatchesSection';
import Footer from '@/components/Footer';

export default function App() {
  const [unlocked, setUnlocked] = useState(false);

  if (!unlocked) {
    return <AdminGateway onUnlock={() => setUnlocked(true)} />;
  }

  return (
    <div className="min-h-screen bg-white">
      <Header />
      <main>
        <TopBanner />
        <BatchesSection />
      </main>
      <Footer />
    </div>
  );
}
