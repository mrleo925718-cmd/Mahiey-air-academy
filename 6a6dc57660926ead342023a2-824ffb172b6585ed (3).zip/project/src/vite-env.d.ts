/// <reference types="vite/client" />

export {};

declare global {
  interface Window {
    netlifyIdentity?: {
      on: (event: string, cb: (user?: NetlifyUser) => void) => void;
      init: (user?: NetlifyUser) => void;
      open: (action?: 'login' | 'signup') => void;
      close: () => void;
      currentUser: () => NetlifyUser | null;
      logout: () => void;
      refresh: () => void;
    };
  }

  interface NetlifyUser {
    id: string;
    email: string;
    user_metadata?: Record<string, string>;
    token?: { access_token?: string; expires_at?: number };
  }
}
