import { useState, useEffect, useCallback } from 'react';

type NetlifyUser = {
  id: string;
  email: string;
};

export function useNetlifyIdentity() {
  const [user, setUser] = useState<NetlifyUser | null>(null);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    let cancelled = false;

    const sync = () => {
      if (cancelled) return;
      const widget = window.netlifyIdentity;
      if (!widget) return;
      const u = widget.currentUser();
      setUser(u ? { id: u.id, email: u.email } : null);
      setReady(true);
    };

    // Widget loads asynchronously; poll briefly until available.
    const start = Date.now();
    const timer = window.setInterval(() => {
      if (window.netlifyIdentity || Date.now() - start > 8000) {
        window.clearInterval(timer);
        const widget = window.netlifyIdentity;
        if (!widget) {
          setReady(true);
          return;
        }
        widget.on('init', (u) => {
          if (cancelled) return;
          setUser(u ? { id: u.id, email: u.email } : null);
          setReady(true);
        });
        widget.on('login', (u) => {
          if (cancelled) return;
          setUser(u ? { id: u.id, email: u.email } : null);
          window.netlifyIdentity?.close();
        });
        widget.on('logout', () => {
          if (cancelled) return;
          setUser(null);
        });
        // Fallback sync in case on('init') already fired
        sync();
      }
    }, 200);

    return () => {
      cancelled = true;
      window.clearInterval(timer);
    };
  }, []);

  const login = useCallback(() => {
    window.netlifyIdentity?.open('login');
  }, []);

  const logout = useCallback(() => {
    window.netlifyIdentity?.logout();
    setUser(null);
  }, []);

  return { user, ready, login, logout };
}
