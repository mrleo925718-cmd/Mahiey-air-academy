// ============================================================
// Parihar Academy — central content & config
// ============================================================

// ---- Payment & access config ----
// Razorpay payment link for premium batch access.
export const PAYMENT_URL = 'https://razorpay.me/@maheyair';

// Admin gateway passcode (front-end gate; Netlify Identity handles real auth).
export const ADMIN_PASSCODE = 'M@hipal2026';

// ---- Profile ----
export const PROFILE = {
  name: 'Mahipal Parihar',
  nickname: 'Mahipal Sir',
  qualification: 'M.Sc, B.Ed',
  expertise: 'Reasoning & Airforce X/Y Expert',
};

// ---- Photography (Pexels, license-free) ----
export const HERO_PHOTO =
  'https://images.pexels.com/photos/8617936/pexels-photo-8617936.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';
export const JAL_MAHAL_PHOTO =
  'https://images.pexels.com/photos/19867655/pexels-photo-19867655.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';

// ============================================================
// Mock test data
// ============================================================

export type Bilingual = { en: string; hi: string };

export type Section = {
  subject: string;
  questionCount: number;
  marksPerQuestion: number;
  negativeMark: number;
};

export type Question = {
  id: string;
  subject: string;
  question: Bilingual;
  options: [Bilingual, Bilingual, Bilingual, Bilingual];
  answer: number; // index 0-3
  explanation: Bilingual;
};

export type MockTest = {
  id: string;
  title: string;
  group: 'X' | 'Y';
  durationMinutes: number;
  totalQuestions: number;
  maxMarks: number;
  sections: Section[];
  questions: Question[];
  comingSoon?: boolean;
};

// ---- English-medium helper content (bilingual) ----
const q = (en: string, hi: string): Bilingual => ({ en, hi });
const opt = q;

// ============================================================
// FREE batch — 2 mock tests (active)
// ============================================================
export const FREE_MOCK_TESTS: MockTest[] = [
  {
    id: 'free-x-01',
    title: 'X-Group Free Mock #1',
    group: 'X',
    durationMinutes: 60,
    totalQuestions: 4,
    maxMarks: 4,
    sections: [
      { subject: 'Physics', questionCount: 1, marksPerQuestion: 1, negativeMark: 0.25 },
      { subject: 'Maths', questionCount: 1, marksPerQuestion: 1, negativeMark: 0.25 },
      { subject: 'English', questionCount: 2, marksPerQuestion: 1, negativeMark: 0.25 },
    ],
    questions: [
      {
        id: 'fx1-p1',
        subject: 'Physics',
        question: q(
          'A body moves with uniform velocity. Its acceleration is:',
          'एक वस्तु एकसमान वेग से चलती है। इसका त्वरण होगा:'
        ),
        options: [
          opt('Zero', 'शून्य'),
          opt('Maximum', 'अधिकतम'),
          opt('Negative', 'ऋणात्मक'),
          opt('Infinite', 'अनंत'),
        ],
        answer: 0,
        explanation: q(
          'Uniform velocity means no change in velocity, so acceleration = 0.',
          'एकसमान वेग का अर्थ वेग में कोई परिवर्तन नहीं, अतः त्वरण = 0।'
        ),
      },
      {
        id: 'fx1-m1',
        subject: 'Maths',
        question: q(
          'If sin θ = 1/2, then θ (0° ≤ θ ≤ 90°) is:',
          'यदि sin θ = 1/2, तो θ (0° ≤ θ ≤ 90°) का मान है:'
        ),
        options: [
          opt('30°', '30°'),
          opt('45°', '45°'),
          opt('60°', '60°'),
          opt('90°', '90°'),
        ],
        answer: 0,
        explanation: q(
          'sin 30° = 1/2, so θ = 30° within the given range.',
          'sin 30° = 1/2, इसलिए दिए गए परिसर में θ = 30°।'
        ),
      },
      {
        id: 'fx1-e1',
        subject: 'English',
        question: q(
          'Choose the correct synonym of "Brave":',
          '"Brave" का सही पर्यायवाची चुनें:'
        ),
        options: [
          opt('Coward', 'कायर'),
          opt('Courageous', 'साहसी'),
          opt('Weak', 'कमज़ोर'),
          opt('Timid', 'डरपोक'),
        ],
        answer: 1,
        explanation: q(
          '"Courageous" means showing courage, i.e. brave.',
          '"Courageous" का अर्थ साहस दिखाना, अर्थात बहादुर।'
        ),
      },
      {
        id: 'fx1-e2',
        subject: 'English',
        question: q(
          'Fill in the blank: "He is good ___ mathematics."',
          'रिक्त स्थान भरें: "He is good ___ mathematics."'
        ),
        options: [opt('in', 'in'), opt('at', 'at'), opt('on', 'on'), opt('with', 'with')],
        answer: 1,
        explanation: q(
          'The correct preposition is "at" — "good at mathematics".',
          'सही पूर्वसर्ग "at" है — "good at mathematics"।'
        ),
      },
    ],
  },
  {
    id: 'free-y-01',
    title: 'Y-Group Free Mock #1',
    group: 'Y',
    durationMinutes: 45,
    totalQuestions: 4,
    maxMarks: 4,
    sections: [
      { subject: 'English', questionCount: 2, marksPerQuestion: 1, negativeMark: 0.25 },
      { subject: 'RAGA', questionCount: 2, marksPerQuestion: 1, negativeMark: 0.25 },
    ],
    questions: [
      {
        id: 'fy1-e1',
        subject: 'English',
        question: q('Choose the correct article: "___ honest man."', 'सही article चुनें: "___ honest man."'),
        options: [opt('A', 'A'), opt('An', 'An'), opt('The', 'The'), opt('No article', 'कोई नहीं')],
        answer: 1,
        explanation: q(
          '"Honest" begins with a silent "h" (vowel sound), so "An" is used.',
          '"Honest" के आरंभ में मौन "h" (स्वर ध्वनि) है, इसलिए "An" लगता है।'
        ),
      },
      {
        id: 'fy1-e2',
        subject: 'English',
        question: q('Antonym of "Ancient":', '"Ancient" का विलोम:'),
        options: [opt('Old', 'पुराना'), opt('Modern', 'आधुनिक'), opt('Historic', 'ऐतिहासिक'), opt('Classic', 'क्लासिक')],
        answer: 1,
        explanation: q('"Modern" is the opposite of "Ancient".', '"Modern", "Ancient" का विलोम है।'),
      },
      {
        id: 'fy1-r1',
        subject: 'RAGA',
        question: q(
          'Complete the series: 2, 6, 12, 20, 30, ?',
          'श्रृंखला पूर्ण करें: 2, 6, 12, 20, 30, ?'
        ),
        options: [opt('40', '40'), opt('42', '42'), opt('44', '44'), opt('46', '46')],
        answer: 1,
        explanation: q(
          'Differences: 4, 6, 8, 10, 12 → next term 30 + 12 = 42.',
          'अंतर: 4, 6, 8, 10, 12 → अगला पद 30 + 12 = 42।'
        ),
      },
      {
        id: 'fy1-r2',
        subject: 'RAGA',
        question: q(
          'If FRIEND is coded as GSJFOE, then HUSBAND is coded as:',
          'यदि FRIEND को GSJFOE लिखा जाता है, तो HUSBAND को लिखा जाएगा:'
        ),
        options: [opt('IVTCBOE', 'IVTCBOE'), opt('ITVCBOE', 'ITVCBOE'), opt('IVTCOBE', 'IVTCOBE'), opt('IVCTBOE', 'IVCTBOE')],
        answer: 0,
        explanation: q(
          'Each letter shifts +1: H→I, U→V, S→T, B→C, A→B, N→O, D→E.',
          'प्रत्येक अक्षर +1 खिसकता है: H→I, U→V, S→T, B→C, A→B, N→O, D→E।'
        ),
      },
    ],
  },
];

// ============================================================
// PAID batch — 10 mock tests (2 active, 8 coming soon)
// ============================================================
export const PAID_MOCK_TESTS: MockTest[] = [
  {
    id: 'paid-x-01',
    title: 'X-Group Premium Mock #1',
    group: 'X',
    durationMinutes: 60,
    totalQuestions: 4,
    maxMarks: 4,
    sections: [
      { subject: 'Physics', questionCount: 1, marksPerQuestion: 1, negativeMark: 0.25 },
      { subject: 'Maths', questionCount: 1, marksPerQuestion: 1, negativeMark: 0.25 },
      { subject: 'English', questionCount: 2, marksPerQuestion: 1, negativeMark: 0.25 },
    ],
    questions: [
      {
        id: 'px1-p1',
        subject: 'Physics',
        question: q(
          'The SI unit of electric current is:',
          'विद्युत धारा का SI मात्रक है:'
        ),
        options: [opt('Volt', 'वोल्ट'), opt('Ampere', 'एम्पीयर'), opt('Ohm', 'ओम'), opt('Watt', 'वाट')],
        answer: 1,
        explanation: q(
          'The SI unit of electric current is the Ampere (A).',
          'विद्युत धारा का SI मात्रक एम्पीयर (A) है।'
        ),
      },
      {
        id: 'px1-m1',
        subject: 'Maths',
        question: q(
          'The value of log₁₀(1000) is:',
          'log₁₀(1000) का मान है:'
        ),
        options: [opt('2', '2'), opt('3', '3'), opt('10', '10'), opt('100', '100')],
        answer: 1,
        explanation: q(
          'log₁₀(1000) = log₁₀(10³) = 3.',
          'log₁₀(1000) = log₁₀(10³) = 3।'
        ),
      },
      {
        id: 'px1-e1',
        subject: 'English',
        question: q('Choose the correctly spelt word:', 'सही वर्तनी वाला शब्द चुनें:'),
        options: [opt('Accomodation', 'Accomodation'), opt('Acommodation', 'Acommodation'), opt('Accommodation', 'Accommodation'), opt('Acomodation', 'Acomodation')],
        answer: 2,
        explanation: q(
          'Correct spelling: "Accommodation" (double c, double m).',
          'सही वर्तनी: "Accommodation" (दो c, दो m)।'
        ),
      },
      {
        id: 'px1-e2',
        subject: 'English',
        question: q(
          'Identify the part of speech of "quickly" in: "She ran quickly."',
          '"She ran quickly." में "quickly" का शब्द-भेद पहचानें:'
        ),
        options: [opt('Noun', 'संज्ञा'), opt('Verb', 'क्रिया'), opt('Adverb', 'क्रिया-विशेषण'), opt('Adjective', 'विशेषण')],
        answer: 2,
        explanation: q(
          '"Quickly" modifies the verb "ran", so it is an adverb.',
          '"Quickly" क्रिया "ran" को विशेषित करता है, अतः यह क्रिया-विशेषण है।'
        ),
      },
    ],
  },
  {
    id: 'paid-y-01',
    title: 'Y-Group Premium Mock #1',
    group: 'Y',
    durationMinutes: 45,
    totalQuestions: 4,
    maxMarks: 4,
    sections: [
      { subject: 'English', questionCount: 2, marksPerQuestion: 1, negativeMark: 0.25 },
      { subject: 'RAGA', questionCount: 2, marksPerQuestion: 1, negativeMark: 0.25 },
    ],
    questions: [
      {
        id: 'py1-e1',
        subject: 'English',
        question: q('Choose the correct preposition: "She is fond ___ music."', 'सही पूर्वसर्ग चुनें: "She is fond ___ music."'),
        options: [opt('of', 'of'), opt('with', 'with'), opt('for', 'for'), opt('in', 'in')],
        answer: 0,
        explanation: q('"Fond of" is the correct phrase.', '"Fond of" सही वाक्यांश है।'),
      },
      {
        id: 'py1-e2',
        subject: 'English',
        question: q('Active to passive: "He writes a letter."', 'कर्तृवाच्य से कर्मवाच्य: "He writes a letter."'),
        options: [
          opt('A letter is written by him.', 'A letter is written by him.'),
          opt('A letter was written by him.', 'A letter was written by him.'),
          opt('A letter has written by him.', 'A letter has written by him.'),
          opt('A letter is being written by him.', 'A letter is being written by him.'),
        ],
        answer: 0,
        explanation: q(
          'Simple present passive: "A letter is written by him."',
          'सामान्य वर्तमान कर्मवाच्य: "A letter is written by him."'
        ),
      },
      {
        id: 'py1-r1',
        subject: 'RAGA',
        question: q(
          'Find the odd one out: 3, 5, 11, 14, 17, 21',
          'असंगत ज्ञात करें: 3, 5, 11, 14, 17, 21'
        ),
        options: [opt('3', '3'), opt('5', '5'), opt('14', '14'), opt('21', '21')],
        answer: 2,
        explanation: q(
          'All are odd primes except 14 (even).',
          '14 को छोड़कर सभी विषम अभाज्य हैं (14 सम है)।'
        ),
      },
      {
        id: 'py1-r2',
        subject: 'RAGA',
        question: q(
          'If 5 + 3 = 28, 9 + 1 = 810, then 8 + 6 = ?',
          'यदि 5 + 3 = 28, 9 + 1 = 810, तो 8 + 6 = ?'
        ),
        options: [opt('214', '214'), opt('214', '214'), opt('4814', '4814'), opt('1414', '1414')],
        answer: 0,
        explanation: q(
          'Pattern: (a−b)(a+b) → (8−6)(8+6) = 214.',
          'पैटर्न: (a−b)(a+b) → (8−6)(8+6) = 214।'
        ),
      },
    ],
  },
  // ---- Coming soon placeholders (8) ----
  ...Array.from({ length: 8 }, (_, i) => ({
    id: `paid-cs-${i + 1}`,
    title: `Premium Mock #${i + 2}`,
    group: (i % 2 === 0 ? 'X' : 'Y') as 'X' | 'Y',
    durationMinutes: i % 2 === 0 ? 60 : 45,
    totalQuestions: 60,
    maxMarks: 60,
    sections:
      i % 2 === 0
        ? [
            { subject: 'Physics', questionCount: 25, marksPerQuestion: 1, negativeMark: 0.25 },
            { subject: 'Maths', questionCount: 25, marksPerQuestion: 1, negativeMark: 0.25 },
            { subject: 'English', questionCount: 10, marksPerQuestion: 1, negativeMark: 0.25 },
          ]
        : [
            { subject: 'English', questionCount: 20, marksPerQuestion: 1, negativeMark: 0.25 },
            { subject: 'RAGA', questionCount: 30, marksPerQuestion: 1, negativeMark: 0.25 },
            { subject: 'GK', questionCount: 10, marksPerQuestion: 1, negativeMark: 0.25 },
          ],
    questions: [],
    comingSoon: true,
  })) as MockTest[],
];
