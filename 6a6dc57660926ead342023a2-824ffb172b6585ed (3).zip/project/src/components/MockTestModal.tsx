import { useState, useEffect, useRef } from 'react';
import { Clock, FileText, Award, Play, Lock, X, ChevronLeft, Languages, ListChecks, AlertTriangle, Clock3 } from 'lucide-react';
import type { MockTest, Question, Bilingual } from '@/data/content';

type Medium = 'en' | 'hi';

type Result = {
  testId: string;
  score: number;
  total: number;
  correct: number;
  wrong: number;
  unanswered: number;
  _answers?: (number | undefined)[];
};

const pick = (b: Bilingual, m: Medium) => b[m];

function ResultView({
  test,
  result,
  medium,
  onRetake,
  onExit,
}: {
  test: MockTest;
  result: Result;
  medium: Medium;
  onRetake: () => void;
  onExit: () => void;
}) {
  const pct = Math.round((result.score / test.maxMarks) * 100);
  const passed = pct >= 40;

  return (
    <div className="animate-fade-in space-y-5">
      <div className="text-center">
        <div className={`mx-auto flex h-16 w-16 items-center justify-center rounded-full ${passed ? 'bg-green-100 text-green-600' : 'bg-red-100 text-red-600'}`}>
          <Award className="h-8 w-8" />
        </div>
        <h3 className="mt-3 text-xl font-bold text-ink-900">Test Submitted</h3>
        <p className="text-sm text-ink-500">{test.title}</p>
      </div>

      <div className="grid grid-cols-3 gap-3">
        <div className="rounded-2xl bg-green-50 p-3 text-center ring-1 ring-green-100">
          <p className="text-2xl font-bold text-green-600">{result.correct}</p>
          <p className="text-[11px] font-medium text-green-700">Correct</p>
        </div>
        <div className="rounded-2xl bg-red-50 p-3 text-center ring-1 ring-red-100">
          <p className="text-2xl font-bold text-red-600">{result.wrong}</p>
          <p className="text-[11px] font-medium text-red-700">Wrong</p>
        </div>
        <div className="rounded-2xl bg-ink-100 p-3 text-center ring-1 ring-ink-200">
          <p className="text-2xl font-bold text-ink-600">{result.unanswered}</p>
          <p className="text-[11px] font-medium text-ink-600">Skipped</p>
        </div>
      </div>

      <div className="rounded-2xl border border-ink-100 bg-ink-50/60 p-4 text-center">
        <p className="text-xs font-semibold uppercase tracking-wider text-ink-400">Your Score</p>
        <p className="mt-1 text-3xl font-extrabold text-ink-900">
          {result.score}
          <span className="text-lg text-ink-400">/{test.maxMarks}</span>
        </p>
        <p className={`mt-1 text-sm font-semibold ${passed ? 'text-green-600' : 'text-red-600'}`}>
          {pct}% {passed ? '· Passed' : '· Needs Work'}
        </p>
      </div>

      <div className="space-y-3">
        <p className="text-xs font-semibold uppercase tracking-wider text-ink-400">Answer Review</p>
        {test.questions.map((q, i) => {
          const userAns = result._answers?.[i];
          const isCorrect = userAns === q.answer;
          const isUnanswered = userAns === undefined;
          return (
            <div key={q.id} className="rounded-2xl border border-ink-100 bg-white p-3.5">
              <div className="flex items-start gap-2.5">
                <span className={`mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-full text-xs font-bold ${isUnanswered ? 'bg-ink-100 text-ink-500' : isCorrect ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
                  {isUnanswered ? '—' : isCorrect ? '✓' : '✕'}
                </span>
                <div className="min-w-0 flex-1">
                  <p className="text-[11px] font-semibold uppercase tracking-wide text-brand-600">{q.subject}</p>
                  <p className="mt-0.5 text-sm font-medium text-ink-800">
                    Q{i + 1}. {pick(q.question, medium)}
                  </p>
                  <p className="mt-1.5 text-xs text-ink-500">
                    Correct: <span className="font-semibold text-green-700">{pick(q.options[q.answer], medium)}</span>
                  </p>
                  {!isUnanswered && !isCorrect && (
                    <p className="text-xs text-ink-500">
                      Your answer: <span className="font-semibold text-red-700">{pick(q.options[userAns as number], medium)}</span>
                    </p>
                  )}
                  <p className="mt-1.5 rounded-lg bg-ink-50 px-2.5 py-1.5 text-xs text-ink-600">{pick(q.explanation, medium)}</p>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      <div className="flex gap-3">
        <button onClick={onExit} className="flex-1 rounded-xl border border-ink-200 bg-white py-2.5 text-sm font-semibold text-ink-700 transition hover:bg-ink-50">
          Back to Mocks
        </button>
        <button onClick={onRetake} className="flex-1 rounded-xl bg-brand-500 py-2.5 text-sm font-semibold text-white transition hover:bg-brand-600">
          Retake Test
        </button>
      </div>
    </div>
  );
}

function TestPlayer({ test, medium, onExit }: { test: MockTest; medium: Medium; onExit: () => void }) {
  const [current, setCurrent] = useState(0);
  const [answers, setAnswers] = useState<(number | undefined)[]>(Array(test.questions.length).fill(undefined));
  const [timeLeft, setTimeLeft] = useState(test.durationMinutes * 60);
  const [submitted, setSubmitted] = useState(false);
  const [result, setResult] = useState<Result | null>(null);
  const [showPalette, setShowPalette] = useState(false);
  const timerRef = useRef<number | null>(null);

  const handleSubmit = () => {
    let correct = 0;
    let wrong = 0;
    let unanswered = 0;
    test.questions.forEach((q, i) => {
      if (answers[i] === undefined) unanswered++;
      else if (answers[i] === q.answer) correct++;
      else wrong++;
    });
    // Real Airforce marking: +1 correct, −0.25 wrong
    const raw = correct * 1 - wrong * 0.25;
    setResult({
      testId: test.id,
      score: Math.max(0, Math.round(raw * 100) / 100),
      total: test.maxMarks,
      correct,
      wrong,
      unanswered,
      _answers: answers,
    });
    setSubmitted(true);
    if (timerRef.current) window.clearInterval(timerRef.current);
  };

  useEffect(() => {
    if (submitted) return;
    timerRef.current = window.setInterval(() => {
      setTimeLeft((t) => {
        if (t <= 1) {
          window.clearInterval(timerRef.current!);
          handleSubmit();
          return 0;
        }
        return t - 1;
      });
    }, 1000);
    return () => {
      if (timerRef.current) window.clearInterval(timerRef.current);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [submitted]);

  if (result) {
    return (
      <ResultView
        test={test}
        result={result}
        medium={medium}
        onRetake={() => {
          setAnswers(Array(test.questions.length).fill(undefined));
          setCurrent(0);
          setTimeLeft(test.durationMinutes * 60);
          setResult(null);
          setSubmitted(false);
        }}
        onExit={onExit}
      />
    );
  }

  const q: Question = test.questions[current];
  const mm = String(Math.floor(timeLeft / 60)).padStart(2, '0');
  const ss = String(timeLeft % 60).padStart(2, '0');
  const low = timeLeft <= 60;
  const answeredCount = answers.filter((a) => a !== undefined).length;

  return (
    <div className="animate-fade-in space-y-5">
      {/* top bar */}
      <div className="flex items-center justify-between gap-3">
        <button onClick={onExit} className="flex items-center gap-1 text-sm font-medium text-ink-500 transition hover:text-ink-800">
          <ChevronLeft className="h-4 w-4" /> Exit
        </button>
        <div className={`flex items-center gap-1.5 rounded-xl px-3 py-1.5 text-sm font-bold tabular-nums ${low ? 'bg-red-100 text-red-600 animate-pulse' : 'bg-ink-100 text-ink-700'}`}>
          <Clock className="h-4 w-4" /> {mm}:{ss}
        </div>
      </div>

      {/* title + sections */}
      <div>
        <p className="text-[11px] font-semibold uppercase tracking-wider text-brand-600">
          {test.group} · {q.subject}
        </p>
        <h3 className="mt-0.5 text-lg font-bold text-ink-900">{test.title}</h3>
        <div className="mt-2 flex flex-wrap gap-1.5">
          {test.sections.map((s) => (
            <span key={s.subject} className="rounded-full bg-ink-100 px-2.5 py-0.5 text-[11px] font-medium text-ink-600">
              {s.subject}: {s.questionCount} Qs · +{s.marksPerQuestion}/−{s.negativeMark}
            </span>
          ))}
        </div>
      </div>

      {/* palette toggle */}
      <div className="flex items-center justify-between gap-3">
        <button
          onClick={() => setShowPalette((s) => !s)}
          className="flex items-center gap-1.5 rounded-lg bg-ink-100 px-3 py-1.5 text-xs font-semibold text-ink-600 transition hover:bg-ink-200"
        >
          <ListChecks className="h-4 w-4" /> {answeredCount}/{test.questions.length} answered
        </button>
      </div>

      {showPalette && (
        <div className="flex flex-wrap gap-2 rounded-2xl bg-ink-100 p-3 animate-fade-in">
          {test.questions.map((_, i) => (
            <button
              key={i}
              onClick={() => {
                setCurrent(i);
                setShowPalette(false);
              }}
              className={`h-8 w-8 rounded-lg text-xs font-bold transition ${i === current ? 'bg-brand-500 text-white' : answers[i] !== undefined ? 'bg-green-100 text-green-700' : 'bg-white text-ink-500 hover:bg-ink-200'}`}
            >
              {i + 1}
            </button>
          ))}
        </div>
      )}

      {/* question */}
      <div className="rounded-2xl border border-ink-100 bg-white p-5">
        <p className="text-xs font-semibold text-ink-400">
          Question {current + 1} of {test.questions.length}
        </p>
        <p className={`mt-2 text-base font-semibold text-ink-900 ${medium === 'hi' ? 'font-hindi' : ''}`}>
          {pick(q.question, medium)}
        </p>
        <div className="mt-4 space-y-2.5">
          {q.options.map((opt, i) => (
            <button
              key={i}
              onClick={() => setAnswers((a) => { const n = [...a]; n[current] = i; return n; })}
              className={`flex w-full items-center gap-3 rounded-xl border p-3.5 text-left text-sm font-medium transition ${answers[current] === i ? 'border-brand-500 bg-brand-50 text-brand-700 ring-1 ring-brand-500/30' : 'border-ink-200 bg-white text-ink-700 hover:border-ink-300 hover:bg-ink-50'}`}
            >
              <span className={`flex h-6 w-6 shrink-0 items-center justify-center rounded-full text-xs font-bold ${answers[current] === i ? 'bg-brand-500 text-white' : 'bg-ink-100 text-ink-500'}`}>
                {String.fromCharCode(65 + i)}
              </span>
              <span className={medium === 'hi' ? 'font-hindi' : ''}>{pick(opt, medium)}</span>
            </button>
          ))}
        </div>
      </div>

      {/* nav */}
      <div className="flex items-center justify-between gap-3">
        <button
          disabled={current === 0}
          onClick={() => setCurrent((c) => Math.max(0, c - 1))}
          className="rounded-xl border border-ink-200 bg-white px-4 py-2.5 text-sm font-semibold text-ink-700 transition hover:bg-ink-50 disabled:opacity-40"
        >
          Previous
        </button>
        {current < test.questions.length - 1 ? (
          <button onClick={() => setCurrent((c) => c + 1)} className="rounded-xl bg-ink-900 px-5 py-2.5 text-sm font-semibold text-white transition hover:bg-ink-800">
            Next
          </button>
        ) : (
          <button onClick={handleSubmit} className="rounded-xl bg-green-600 px-5 py-2.5 text-sm font-semibold text-white transition hover:bg-green-700">
            Submit Test
          </button>
        )}
      </div>
    </div>
  );
}

function MediumSelector({ medium, setMedium }: { medium: Medium; setMedium: (m: Medium) => void }) {
  return (
    <div className="flex items-center gap-2">
      <span className="flex items-center gap-1.5 text-xs font-semibold text-ink-500">
        <Languages className="h-4 w-4" /> Medium
      </span>
      <div className="flex rounded-xl bg-ink-100 p-1">
        {(['en', 'hi'] as Medium[]).map((m) => (
          <button
            key={m}
            onClick={() => setMedium(m)}
            className={`rounded-lg px-3 py-1 text-xs font-bold transition ${medium === m ? 'bg-white text-brand-600 shadow-sm' : 'text-ink-500 hover:text-ink-700'}`}
          >
            {m === 'en' ? 'English' : 'हिंदी'}
          </button>
        ))}
      </div>
    </div>
  );
}

export default function MockTestModal({
  tests,
  batchLabel,
  onClose,
}: {
  tests: MockTest[];
  batchLabel: string;
  onClose: () => void;
}) {
  const [active, setActive] = useState<MockTest | null>(null);
  const [medium, setMedium] = useState<Medium>('en');

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-ink-950/60 p-4 backdrop-blur-sm animate-fade-in"
      onClick={onClose}
    >
      <div
        className="relative w-full max-w-2xl animate-scale-in rounded-3xl bg-ink-50 p-6 shadow-2xl max-h-[90vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          onClick={onClose}
          className="absolute right-4 top-4 rounded-lg p-1.5 text-ink-400 transition hover:bg-ink-100 hover:text-ink-700"
          aria-label="Close"
        >
          <X className="h-5 w-5" />
        </button>

        {!active ? (
          <div className="animate-fade-in">
            <div className="mb-5 flex flex-wrap items-start justify-between gap-4">
              <div>
                <p className="text-[11px] font-semibold uppercase tracking-wider text-brand-600">
                  {batchLabel}
                </p>
                <h2 className="mt-1 text-xl font-bold text-ink-900">Mock Tests</h2>
                <p className="mt-1 text-sm text-ink-500">
                  Real Airforce exam pattern — attempt in Hindi or English medium.
                </p>
              </div>
              <MediumSelector medium={medium} setMedium={setMedium} />
            </div>

            <div className="mb-4 flex items-start gap-2 rounded-xl bg-brand-50 p-3 text-xs text-brand-700 ring-1 ring-brand-100">
              <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" />
              <span>
                Marking scheme: <strong>+1</strong> for correct, <strong>−0.25</strong> for wrong. X-Group: 60 min · Physics, Maths, English. Y-Group: 45 min · English + RAGA.
              </span>
            </div>

            <div className="space-y-3">
              {tests.map((t) =>
                t.comingSoon ? (
                  <div
                    key={t.id}
                    className="group flex w-full items-center gap-4 rounded-2xl border border-dashed border-ink-200 bg-ink-50/50 p-4 text-left"
                  >
                    <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-ink-100 text-ink-400">
                      <Clock3 className="h-6 w-6" />
                    </span>
                    <div className="min-w-0 flex-1">
                      <p className="font-semibold text-ink-500">{t.title}</p>
                      <div className="mt-1 flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-ink-400">
                        <span className="flex items-center gap-1"><Clock className="h-3.5 w-3.5" /> {t.durationMinutes} min</span>
                        <span className="flex items-center gap-1"><FileText className="h-3.5 w-3.5" /> {t.totalQuestions} Qs</span>
                      </div>
                      <div className="mt-1.5 flex flex-wrap gap-1">
                        {t.sections.map((s) => (
                          <span key={s.subject} className="rounded bg-ink-100 px-1.5 py-0.5 text-[10px] font-medium text-ink-400">
                            {s.subject}
                          </span>
                        ))}
                      </div>
                    </div>
                    <span className="shrink-0 rounded-full bg-ink-200/70 px-3 py-1 text-[11px] font-bold uppercase tracking-wide text-ink-500">
                      Coming Soon
                    </span>
                  </div>
                ) : (
                  <button
                    key={t.id}
                    onClick={() => setActive(t)}
                    className="group flex w-full items-center gap-4 rounded-2xl border border-ink-200 bg-white p-4 text-left transition hover:border-brand-300 hover:shadow-card"
                  >
                    <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-brand-100 text-brand-600 transition group-hover:bg-brand-500 group-hover:text-white">
                      <FileText className="h-6 w-6" />
                    </span>
                    <div className="min-w-0 flex-1">
                      <p className="font-semibold text-ink-900">{t.title}</p>
                      <div className="mt-1 flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-ink-500">
                        <span className="flex items-center gap-1"><Clock className="h-3.5 w-3.5" /> {t.durationMinutes} min</span>
                        <span className="flex items-center gap-1"><FileText className="h-3.5 w-3.5" /> {t.totalQuestions} Qs</span>
                        <span className="flex items-center gap-1"><Award className="h-3.5 w-3.5" /> {t.maxMarks} marks</span>
                      </div>
                      <div className="mt-1 flex flex-wrap gap-1">
                        {t.sections.map((s) => (
                          <span key={s.subject} className="rounded bg-ink-100 px-1.5 py-0.5 text-[10px] font-medium text-ink-500">
                            {s.subject}
                          </span>
                        ))}
                      </div>
                    </div>
                    <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-brand-500 text-white transition group-hover:scale-110">
                      <Play className="h-4 w-4" />
                    </span>
                  </button>
                )
              )}
            </div>
            <p className="mt-4 flex items-center justify-center gap-1.5 text-xs text-ink-400">
              <Lock className="h-3.5 w-3.5" /> Marking: +1 correct · −0.25 wrong
            </p>
          </div>
        ) : (
          <div className="animate-fade-in">
            <div className="mb-4 flex items-center justify-between">
              <div className="flex items-center gap-2 text-sm font-semibold text-ink-700">
                <span className={`rounded-lg px-2 py-0.5 ${medium === 'en' ? 'bg-brand-100 text-brand-700' : 'bg-ink-100 text-ink-600'}`}>
                  {medium === 'en' ? 'English' : 'हिंदी'}
                </span>
              </div>
              <MediumSelector medium={medium} setMedium={setMedium} />
            </div>
            <TestPlayer test={active} medium={medium} onExit={() => setActive(null)} />
          </div>
        )}
      </div>
    </div>
  );
}
