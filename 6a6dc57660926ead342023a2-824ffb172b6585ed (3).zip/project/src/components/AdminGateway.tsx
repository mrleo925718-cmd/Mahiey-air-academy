import { useState } from 'react';
import { Lock, Eye, EyeOff, ShieldCheck, AlertCircle } from 'lucide-react';
import { ADMIN_PASSCODE } from '@/data/content';

type Props = {
  onUnlock: () => void;
};

export default function AdminGateway({ onUnlock }: Props) {
  const [passcode, setPasscode] = useState('');
  const [show, setShow] = useState(false);
  const [error, setError] = useState('');
  const [shake, setShake] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (passcode.trim() === ADMIN_PASSCODE) {
      setError('');
      onUnlock();
    } else {
      setError('Incorrect passcode. Access denied.');
      setShake(true);
      setTimeout(() => setShake(false), 450);
    }
  };

  return (
    <div className="relative min-h-screen w-full overflow-hidden bg-ink-950 flex items-center justify-center p-4">
      {/* ambient glows */}
      <div className="pointer-events-none absolute -top-24 -left-24 h-96 w-96 rounded-full bg-brand-600/20 blur-3xl" />
      <div className="pointer-events-none absolute -bottom-32 -right-24 h-96 w-96 rounded-full bg-brand-500/10 blur-3xl" />
      <div className="pointer-events-none absolute inset-0 opacity-[0.04]" style={{ backgroundImage: 'radial-gradient(circle, #fff 1px, transparent 1px)', backgroundSize: '32px 32px' }} />

      <div
        className={`relative w-full max-w-md animate-scale-in rounded-3xl bg-white p-8 sm:p-10 shadow-2xl ${shake ? 'animate-shake' : ''}`}
      >
        {/* orange accent bar */}
        <div className="absolute -top-1 left-8 right-8 h-1.5 rounded-full bg-gradient-to-r from-brand-400 via-brand-500 to-brand-600" />

        {/* Hindi logo */}
        <div className="mb-7 text-center">
          <p className="logo-hindi text-3xl sm:text-4xl text-ink-900">महिपाल परिहार</p>
          <p className="mt-1 text-xs font-semibold uppercase tracking-[0.3em] text-brand-600">Parihar Academy</p>
        </div>

        {/* shield icon */}
        <div className="mx-auto mb-5 flex h-14 w-14 items-center justify-center rounded-2xl bg-brand-50 text-brand-600 ring-1 ring-brand-200">
          <ShieldCheck className="h-7 w-7" />
        </div>

        <h1 className="text-center text-2xl font-bold text-ink-900">Admin Security</h1>
        <p className="mt-2 text-center text-sm text-ink-500">Enter Passcode to access Parihar Academy</p>

        <form onSubmit={handleSubmit} className="mt-7 space-y-4">
          <div>
            <label htmlFor="passcode" className="mb-1.5 block text-xs font-semibold uppercase tracking-wider text-ink-600">
              Passcode
            </label>
            <div className="relative">
              <Lock className="pointer-events-none absolute left-3.5 top-1/2 h-5 w-5 -translate-y-1/2 text-ink-400" />
              <input
                id="passcode"
                type={show ? 'text' : 'password'}
                value={passcode}
                onChange={(e) => {
                  setPasscode(e.target.value);
                  if (error) setError('');
                }}
                placeholder="Enter Passcode..."
                autoFocus
                className="w-full rounded-xl border border-ink-200 bg-ink-50/60 py-3 pl-11 pr-11 text-ink-900 placeholder-ink-400 outline-none transition focus:border-brand-500 focus:bg-white focus:ring-2 focus:ring-brand-500/20"
              />
              <button
                type="button"
                onClick={() => setShow((s) => !s)}
                className="absolute right-3 top-1/2 -translate-y-1/2 rounded-lg p-1 text-ink-400 transition hover:text-ink-600"
                aria-label={show ? 'Hide passcode' : 'Show passcode'}
              >
                {show ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
              </button>
            </div>
          </div>

          {error && (
            <div className="flex items-center gap-2 rounded-xl bg-red-50 px-3.5 py-2.5 text-sm font-medium text-red-600 ring-1 ring-red-200">
              <AlertCircle className="h-4 w-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          <button
            type="submit"
            className="w-full rounded-xl bg-brand-500 py-3.5 text-center font-semibold text-white shadow-lg shadow-brand-500/30 transition hover:bg-brand-600 active:scale-[0.98]"
          >
            Unlock Platform
          </button>
        </form>

        <p className="mt-6 text-center text-xs text-ink-400">
          Authorized personnel only. Attempts are monitored.
        </p>
      </div>
    </div>
  );
}
