import { Plane, BadgeCheck, GraduationCap, Sparkles } from 'lucide-react';
import { HERO_PHOTO, JAL_MAHAL_PHOTO } from '@/data/content';

export default function TopBanner() {
  return (
    <section className="relative overflow-hidden bg-ink-950">
      {/* background jal mahal */}
      <div className="absolute inset-0">
        <img
          src={JAL_MAHAL_PHOTO}
          alt="Jal Mahal, Jaipur"
          className="h-full w-full object-cover opacity-25"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-ink-950 via-ink-950/85 to-ink-950/40" />
        <div className="absolute inset-0 bg-gradient-to-t from-ink-950 via-transparent to-transparent" />
      </div>

      <div className="relative mx-auto grid max-w-6xl items-center gap-8 px-4 py-12 sm:px-6 sm:py-16 lg:grid-cols-2 lg:py-20">
        {/* left: text */}
        <div className="order-2 lg:order-1">
          <span className="inline-flex items-center gap-2 rounded-full bg-brand-500/15 px-3.5 py-1.5 text-xs font-semibold uppercase tracking-wider text-brand-300 ring-1 ring-brand-500/30">
            <Sparkles className="h-3.5 w-3.5" /> India's Best Airforce Coaching
          </span>

          <h1 className="mt-5 text-4xl font-extrabold leading-[1.08] tracking-tight text-white sm:text-5xl lg:text-[3.4rem]">
            Crack Airforce <span className="text-brand-400">X &amp; Y</span>
            <br />
            With India's Best
          </h1>

          <p className="mt-4 max-w-md text-base text-ink-300 sm:text-lg">
            Expert-led batches, real exam-pattern mocks, and reasoning mastery — designed to get you selected.
          </p>

          {/* badges */}
          <div className="mt-7 flex flex-wrap gap-3">
            <div className="flex items-center gap-2 rounded-xl bg-white/10 px-4 py-2.5 backdrop-blur-sm ring-1 ring-white/15">
              <GraduationCap className="h-5 w-5 text-brand-400" />
              <span className="text-sm font-medium text-white">By Mahipal Sir</span>
            </div>
            <div className="flex items-center gap-2 rounded-xl bg-white/10 px-4 py-2.5 backdrop-blur-sm ring-1 ring-white/15">
              <BadgeCheck className="h-5 w-5 text-brand-400" />
              <span className="text-sm font-medium text-white">Selection Assured</span>
            </div>
          </div>
        </div>

        {/* right: photo + plane badge */}
        <div className="order-1 lg:order-2">
          <div className="relative mx-auto max-w-md">
            {/* plane badge */}
            <div className="absolute -top-4 -right-2 z-20 rotate-6 sm:-right-6">
              <div className="flex items-center gap-2 rounded-2xl bg-brand-500 px-3.5 py-2.5 shadow-glow ring-2 ring-white/20">
                <Plane className="h-5 w-5 text-white" />
                <span className="text-sm font-bold uppercase tracking-wide text-white">Selection Assured</span>
              </div>
            </div>

            {/* photo frame */}
            <div className="relative overflow-hidden rounded-3xl ring-1 ring-white/15 shadow-2xl">
              <img
                src={HERO_PHOTO}
                alt="Mahipal Parihar at Jal Mahal"
                className="aspect-[4/3] w-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-ink-950/70 via-transparent to-transparent" />
              <div className="absolute bottom-3 left-4 rounded-lg bg-ink-950/60 px-3 py-1.5 backdrop-blur-sm">
                <p className="text-xs font-medium text-white">Mahipal Parihar · Jal Mahal, Jaipur</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
