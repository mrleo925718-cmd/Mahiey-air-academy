import { Plane, Heart, Code2 } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-ink-100 px-4 py-10 sm:px-6">
      <div className="mx-auto max-w-6xl">
        <div className="rounded-2xl bg-white p-6 shadow-soft ring-1 ring-ink-100 sm:p-8">
          <div className="flex flex-col items-center gap-5 text-center sm:flex-row sm:justify-between sm:text-left">
            {/* logo block */}
            <div className="flex items-center gap-3">
              <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-brand-500 text-white shadow-lg shadow-brand-500/25">
                <Plane className="h-6 w-6" />
              </span>
              <div>
                <p className="logo-hindi text-xl text-ink-900">महिपाल परिहार</p>
                <p className="text-[10px] font-semibold uppercase tracking-[0.25em] text-brand-600">Parihar Academy</p>
              </div>
            </div>

            {/* links */}
            <nav className="flex flex-wrap items-center justify-center gap-x-5 gap-y-2 text-sm font-medium text-ink-600">
              <a href="#batches" className="transition hover:text-brand-600">Batches</a>
              <a href="#batches" className="transition hover:text-brand-600">Mock Tests</a>
              <a href="#batches" className="transition hover:text-brand-600">Offers</a>
              <a href="#batches" className="transition hover:text-brand-600">Contact</a>
            </nav>
          </div>

          <div className="my-6 h-px bg-ink-100" />

          <div className="flex flex-col items-center justify-between gap-3 text-center sm:flex-row sm:text-left">
            <p className="text-xs text-ink-500">
              © 2026 Parihar Airforce Academy. All Rights Reserved.
            </p>
            <p className="flex items-center gap-1.5 text-xs text-ink-500">
              <span>Developed by Mahipal Parihar</span>
              <Heart className="h-3.5 w-3.5 fill-brand-500 text-brand-500" />
              <Code2 className="h-3.5 w-3.5 text-ink-400" />
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
}
