import { useState, useEffect } from 'react';
import { Clock, FileText, CheckCircle2, Lock, Play, BadgeCheck, Gift, Sparkles } from 'lucide-react';
import { FREE_MOCK_TESTS, PAID_MOCK_TESTS, PAYMENT_URL } from '@/data/content';
import MockTestModal from './MockTestModal';
import { useNetlifyIdentity } from '@/hooks/useNetlifyIdentity';

export default function BatchesSection() {
  const [mockOpen, setMockOpen] = useState(false);
  const [paidMockOpen, setPaidMockOpen] = useState(false);
  const [paidAccess, setPaidAccess] = useState(false);

  // free batch: once accessed, stays accessible (simulated enrollment)
  const [freeAccess, setFreeAccess] = useState(false);

  const { user, login, logout } = useNetlifyIdentity();

  // Grant paid access if the logged-in user has already paid (tracked in localStorage)
  useEffect(() => {
    if (user && localStorage.getItem(`paid_${user.id}`) === '1') {
      setPaidAccess(true);
    }
    if (!user) setPaidAccess(false);
  }, [user]);

  const handlePaidClick = () => {
    if (!user) {
      // Not logged in — open the Netlify login modal
      login();
      return;
    }
    // Logged in — mark intent, then redirect to the Razorpay payment page.
    // On return the user is still logged in and paidAccess is restored.
    localStorage.setItem(`paid_${user.id}`, '1');
    window.location.href = PAYMENT_URL;
  };

  return (
    <section id="batches" className="relative bg-ink-50 py-16 sm:py-20">
      <div className="mx-auto max-w-6xl px-4 sm:px-6">
        {/* heading */}
        <div className="mx-auto max-w-2xl text-center">
          <span className="inline-flex items-center gap-2 rounded-full bg-brand-100 px-3.5 py-1.5 text-xs font-semibold uppercase tracking-wider text-brand-700">
            <Sparkles className="h-3.5 w-3.5" /> Enroll Now
          </span>
          <h2 className="mt-4 text-3xl font-extrabold tracking-tight text-ink-900 sm:text-4xl">
            Popular Batches &amp; Mocks
          </h2>
          <p className="mt-3 text-base text-ink-500">
            Hand-crafted by Mahipal Sir — choose a batch, attempt real exam-pattern mocks, and track your selection readiness.
          </p>
        </div>

        {/* special offers row */}
        <div className="mt-12 grid gap-5 sm:grid-cols-2">
          {/* offer 1 — सावन स्पेशल ऑफर */}
          <div className="relative overflow-hidden rounded-3xl bg-ink-900 p-6 text-white shadow-card sm:p-7">
            <div className="pointer-events-none absolute -right-10 -top-10 h-40 w-40 rounded-full bg-brand-500/20 blur-2xl" />
            <div className="relative">
              <div className="flex items-center gap-3">
                <span className="flex h-11 w-11 items-center justify-center rounded-2xl bg-white/10 text-2xl ring-1 ring-white/15">🌿</span>
                <div>
                  <p className="font-hindi text-lg font-semibold">सावन स्पेशल ऑफर</p>
                  <p className="text-xs text-white/60">Limited time · Monsoon blessing</p>
                </div>
              </div>
              <p className="mt-4 text-sm leading-relaxed text-white/80">
                इस सावन के पावन माह में पाएं विशेष आशीर्वाद और छूट। मेहनत के साथ शिव का आशीर्वाद, सफलता पक्की।
              </p>
              <button className="mt-5 inline-flex items-center gap-2 rounded-xl bg-brand-500 px-5 py-2.5 text-sm font-semibold text-white transition hover:bg-brand-600 active:scale-95">
                <Gift className="h-4 w-4" /> Claim Blessing &amp; Offer
              </button>
            </div>
          </div>

          {/* offer 2 — हर हर महादेव */}
          <div className="relative overflow-hidden rounded-3xl bg-ink-900 p-6 text-white shadow-card sm:p-7">
            <div className="pointer-events-none absolute -right-10 -top-10 h-40 w-40 rounded-full bg-brand-500/20 blur-2xl" />
            <div className="relative">
              <div className="flex items-center gap-3">
                <span className="flex h-11 w-11 items-center justify-center rounded-2xl bg-white/10 text-2xl ring-1 ring-white/15">✝️</span>
                <div>
                  <p className="font-hindi text-lg font-semibold">हर हर महादेव</p>
                  <p className="text-xs text-white/60">Divine blessing for aspirants</p>
                </div>
              </div>
              <p className="mt-4 text-sm leading-relaxed text-white/80">
                भगवान शिव का आशीर्वाद सभी छात्रों के साथ रहे। दृढ़ संकल्प और श्रद्धा से कोई भी लक्ष्य प्राप्त किया जा सकता है।
              </p>
              <button className="mt-5 inline-flex items-center gap-2 rounded-xl bg-white/10 px-5 py-2.5 text-sm font-semibold text-white ring-1 ring-white/15 transition hover:bg-white/15 active:scale-95">
                <BadgeCheck className="h-4 w-4" /> Receive Blessing
              </button>
            </div>
          </div>
        </div>

        {/* batches grid */}
        <div className="mt-8 grid gap-6 lg:grid-cols-2">
          {/* X & Y Both Target Batch — FREE */}
          <article className="group relative overflow-hidden rounded-3xl bg-white shadow-card ring-1 ring-ink-100 transition hover:shadow-glow">
            <div className="relative h-44 overflow-hidden">
              <img
                src="https://images.pexels.com/photos/19237305/pexels-photo-19237305.jpeg?auto=compress&cs=tinysrgb&h=650&w=940"
                alt="Airforce jet"
                className="h-full w-full object-cover transition duration-700 group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-ink-950/80 via-ink-950/20 to-transparent" />
              <span className="absolute left-4 top-4 rounded-full bg-green-500 px-3 py-1 text-xs font-bold uppercase tracking-wide text-white shadow-lg">
                Free
              </span>
              <div className="absolute bottom-3 left-4 right-4">
                <h3 className="text-xl font-bold text-white">X &amp; Y Both Target Batch</h3>
                <p className="text-xs text-white/80">Full preparation for Airforce X &amp; Y Group</p>
              </div>
            </div>

            <div className="p-5 sm:p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs font-medium text-ink-500">By Mahipal Sir</p>
                  <div className="mt-1.5 flex items-baseline gap-2">
                    <span className="text-3xl font-extrabold text-green-600">FREE</span>
                    <span className="text-base font-medium text-ink-400 line-through">₹1,999</span>
                  </div>
                </div>
                <div className="flex flex-col items-end gap-1">
                  <span className="flex items-center gap-1.5 text-xs font-medium text-ink-500"><Clock className="h-3.5 w-3.5" /> Full-length mocks</span>
                  <span className="flex items-center gap-1.5 text-xs font-medium text-ink-500"><FileText className="h-3.5 w-3.5" /> 2 Mock tests</span>
                </div>
              </div>

              <div className="mt-4 flex flex-wrap gap-2">
                {['Bilingual (हिंदी/English)', 'X-Group: 60 min', 'Y-Group: 45 min', '+1 / −0.25'].map((t) => (
                  <span key={t} className="rounded-full bg-ink-100 px-2.5 py-1 text-[11px] font-medium text-ink-600">{t}</span>
                ))}
              </div>

              {freeAccess ? (
                <button
                  onClick={() => setMockOpen(true)}
                  className="mt-5 flex w-full items-center justify-center gap-2 rounded-xl bg-brand-500 py-3.5 font-semibold text-white shadow-lg shadow-brand-500/25 transition hover:bg-brand-600 active:scale-[0.98]"
                >
                  <Play className="h-5 w-5" /> Start Mock Tests
                </button>
              ) : (
                <button
                  onClick={() => setFreeAccess(true)}
                  className="mt-5 flex w-full items-center justify-center gap-2 rounded-xl border-2 border-green-500 bg-green-50 py-3.5 font-semibold text-green-700 transition hover:bg-green-100 active:scale-[0.98]"
                >
                  <CheckCircle2 className="h-5 w-5" /> Access Free Batch
                </button>
              )}
            </div>
          </article>

          {/* X & Y Both Target Batch — ₹49 */}
          <article className="group relative overflow-hidden rounded-3xl bg-white shadow-card ring-1 ring-ink-100 transition hover:shadow-glow">
            <div className="relative h-44 overflow-hidden">
              <img
                src="https://images.pexels.com/photos/122136/pexels-photo-122136.jpeg?auto=compress&cs=tinysrgb&h=650&w=940"
                alt="Airforce jet"
                className="h-full w-full object-cover transition duration-700 group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-ink-950/80 via-ink-950/20 to-transparent" />
              <span className="absolute left-4 top-4 rounded-full bg-brand-500 px-3 py-1 text-xs font-bold uppercase tracking-wide text-white shadow-lg">
                Premium
              </span>
              <div className="absolute bottom-3 left-4 right-4">
                <h3 className="text-xl font-bold text-white">X &amp; Y Both Target Batch</h3>
                <p className="text-xs text-white/80">Complete X &amp; Y Group test series with 10 mock tests</p>
              </div>
            </div>

            <div className="p-5 sm:p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs font-medium text-ink-500">By Mahipal Sir</p>
                  <div className="mt-1.5 flex items-baseline gap-2">
                    <span className="text-3xl font-extrabold text-ink-900">₹49</span>
                    <span className="text-base font-medium text-ink-400 line-through">₹299</span>
                  </div>
                </div>
                <div className="flex flex-col items-end gap-1">
                  <span className="flex items-center gap-1.5 text-xs font-medium text-ink-500"><FileText className="h-3.5 w-3.5" /> 10 Mock tests</span>
                  <span className="flex items-center gap-1.5 text-xs font-medium text-green-600"><BadgeCheck className="h-3.5 w-3.5" /> 83% OFF</span>
                </div>
              </div>

              <div className="mt-4 flex flex-wrap gap-2">
                {['Bilingual (हिंदी/English)', 'X & Y Both', '2 Active + 8 Coming Soon', '+1 / −0.25'].map((t) => (
                  <span key={t} className="rounded-full bg-ink-100 px-2.5 py-1 text-[11px] font-medium text-ink-600">{t}</span>
                ))}
              </div>

              {paidAccess ? (
                <>
                  <button
                    onClick={() => setPaidMockOpen(true)}
                    className="mt-5 flex w-full items-center justify-center gap-2 rounded-xl bg-green-600 py-3.5 font-semibold text-white shadow-lg shadow-green-600/25 transition hover:bg-green-700 active:scale-[0.98]"
                  >
                    <Play className="h-5 w-5" /> Open Tests
                  </button>
                  {user && (
                    <div className="mt-3 flex items-center justify-center gap-2 text-xs text-ink-400">
                      <span>Signed in as {user.email}</span>
                      <button onClick={logout} className="font-semibold text-brand-600 hover:underline">
                        Sign out
                      </button>
                    </div>
                  )}
                </>
              ) : (
                <button
                  onClick={handlePaidClick}
                  className="mt-5 flex w-full items-center justify-center gap-2 rounded-xl bg-ink-900 py-3.5 font-semibold text-white shadow-lg shadow-ink-900/20 transition hover:bg-ink-800 active:scale-[0.98]"
                >
                  <Lock className="h-5 w-5" /> {user ? 'Pay & Access Now' : 'Login to Access'}
                </button>
              )}
            </div>
          </article>
        </div>
      </div>

      {mockOpen && <MockTestModal tests={FREE_MOCK_TESTS} batchLabel="X & Y Both Target Batch · Free Access" onClose={() => setMockOpen(false)} />}
      {paidMockOpen && <MockTestModal tests={PAID_MOCK_TESTS} batchLabel="X & Y Both Target Batch · Premium" onClose={() => setPaidMockOpen(false)} />}
    </section>
  );
}
