import { useState } from 'react';
import { User, X, Contact, Sparkles, GraduationCap, Brain, LogOut, LogIn } from 'lucide-react';
import { PROFILE } from '@/data/content';
import { useNetlifyIdentity } from '@/hooks/useNetlifyIdentity';

function ProfileModal({
  onClose,
  user,
  logout,
}: {
  onClose: () => void;
  user: { id: string; email: string } | null;
  logout: () => void;
}) {
  const items = [
    { icon: Contact, label: 'Name', value: PROFILE.name },
    { icon: Sparkles, label: 'Nickname', value: PROFILE.nickname },
    { icon: GraduationCap, label: 'Qualification', value: PROFILE.qualification },
    { icon: Brain, label: 'Expertise', value: PROFILE.expertise },
  ];

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-ink-950/60 p-4 backdrop-blur-sm animate-fade-in"
      onClick={onClose}
    >
      <div
        className="relative w-full max-w-md animate-scale-in overflow-hidden rounded-3xl bg-white shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        {/* header band */}
        <div className="relative bg-gradient-to-br from-brand-500 to-brand-600 px-6 pb-16 pt-7 text-white">
          <button
            onClick={onClose}
            className="absolute right-4 top-4 rounded-lg p-1.5 text-white/80 transition hover:bg-white/15 hover:text-white"
            aria-label="Close profile"
          >
            <X className="h-5 w-5" />
          </button>
          <p className="text-xs font-semibold uppercase tracking-[0.25em] text-white/70">Profile</p>
          <h2 className="mt-1 text-2xl font-bold">{PROFILE.name}</h2>
          <p className="text-sm text-white/80">"{PROFILE.nickname}" · Reasoning Expert</p>
        </div>

        {/* avatar */}
        <div className="absolute right-6 top-[72px] flex h-20 w-20 items-center justify-center rounded-2xl bg-white text-brand-600 shadow-lg ring-4 ring-white">
          <User className="h-10 w-10" />
        </div>

        {/* list */}
        <div className="px-6 pb-6 pt-8">
          <ul className="space-y-3">
            {items.map(({ icon: Icon, label, value }) => (
              <li key={label} className="flex items-start gap-3.5 rounded-2xl border border-ink-100 bg-ink-50/60 p-3.5">
                <span className="mt-0.5 flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-brand-100 text-brand-600">
                  <Icon className="h-5 w-5" />
                </span>
                <div className="min-w-0">
                  <p className="text-[11px] font-semibold uppercase tracking-wider text-ink-400">{label}</p>
                  <p className="text-sm font-medium text-ink-800">{value}</p>
                </div>
              </li>
            ))}
          </ul>

          <button
            onClick={logout}
            className="mt-5 flex w-full items-center justify-center gap-2 rounded-xl border border-ink-200 bg-white py-2.5 text-sm font-semibold text-ink-600 transition hover:bg-ink-50"
          >
            <LogOut className="h-4 w-4" /> Sign out
          </button>
          {user && (
            <p className="mt-2 text-center text-xs text-ink-400">Signed in as {user.email}</p>
          )}
        </div>
      </div>
    </div>
  );
}

export default function Header() {
  const [profileOpen, setProfileOpen] = useState(false);
  const { user, login, logout } = useNetlifyIdentity();

  const openProfileOrLogin = () => {
    if (user) {
      setProfileOpen(true);
    } else {
      login();
    }
  };

  return (
    <>
      <header className="sticky top-0 z-40 border-b border-ink-100 bg-white/95 backdrop-blur-md">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-3.5 sm:px-6">
          {/* Hindi logo */}
          <div className="flex flex-col leading-none">
            <span className="logo-hindi text-2xl text-ink-900 sm:text-[26px]">महिपाल परिहार</span>
            <span className="mt-0.5 text-[10px] font-semibold uppercase tracking-[0.28em] text-brand-600">
              Parihar Academy
            </span>
          </div>

          {/* user icon */}
          <button
            onClick={openProfileOrLogin}
            className="group flex items-center gap-2 rounded-full border border-ink-200 bg-white p-1 pr-1 transition hover:border-brand-300 hover:shadow-soft"
            aria-label={user ? 'Open profile' : 'Login'}
          >
            <span className="flex h-9 w-9 items-center justify-center rounded-full bg-brand-500 text-white transition group-hover:bg-brand-600">
              {user ? <User className="h-5 w-5" /> : <LogIn className="h-5 w-5" />}
            </span>
          </button>
        </div>
      </header>

      {profileOpen && (
        <ProfileModal
          onClose={() => setProfileOpen(false)}
          user={user}
          logout={logout}
        />
      )}
    </>
  );
}
